package com.fedex.todoitems.todoitemstask;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodoItemsTaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
