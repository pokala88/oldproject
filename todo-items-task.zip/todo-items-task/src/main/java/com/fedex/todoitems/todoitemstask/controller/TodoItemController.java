package com.fedex.todoitems.todoitemstask.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fedex.todoitems.todoitemstask.exception.ResourceNotFoundException;
import com.fedex.todoitems.todoitemstask.model.TodoItem;
import com.fedex.todoitems.todoitemstask.repository.TodoItemRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1")
public class TodoItemController {

	@Autowired
	TodoItemRepository todoItemRepository;

	@GetMapping("/todoitem")
	public List<TodoItem> getAllTodoItems() throws ResourceNotFoundException{	
		return todoItemRepository.findAll();
	}

	@GetMapping("/todoitem/{id}")
	public ResponseEntity<TodoItem> getTodoItemById(@PathVariable(value = "id") Integer id)
			throws ResourceNotFoundException {
		TodoItem todoItem = todoItemRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Todo Item not found for this id :: " + id));
		return ResponseEntity.ok().body(todoItem);
	}

	@PostMapping("/todoitem")
	public TodoItem createTodoItem(@RequestBody TodoItem todoItem) {
		return todoItemRepository.save(todoItem);
	}

	@PutMapping("/todoitem/{id}")
	public ResponseEntity<TodoItem> updateTodoItem(@PathVariable(value = "id") Integer id,
			@RequestBody TodoItem todoItemDetails) throws ResourceNotFoundException {
		TodoItem todoItem = todoItemRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Todo item not found for this id :: " + id));
		todoItem.setId(id);
		todoItem.setItemName(todoItemDetails.getItemName());
		todoItem.setDescription(todoItemDetails.getDescription());
		todoItem.setStatus(todoItemDetails.getStatus());
		final TodoItem updatedTodoItem = todoItemRepository.save(todoItem);
		return ResponseEntity.ok(updatedTodoItem);
	}

	@DeleteMapping("/todoitem/{id}")
	public Map<String, Boolean> deleteTodoItem(@PathVariable(value = "id") Integer id)
			throws ResourceNotFoundException {
		TodoItem todoItem = todoItemRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Todo item not found for this id :: " + id));

		todoItemRepository.delete(todoItem);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}

}
