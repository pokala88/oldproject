package com.fedex.todoitems.todoitemstask.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fedex.todoitems.todoitemstask.model.TodoItem;
import com.fedex.todoitems.todoitemstask.repository.TodoItemRepository;

@RunWith(SpringRunner.class)
@WebMvcTest(value = TodoItemController.class)
class TodoItemControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@InjectMocks
	TodoItemController todoItemController;

	@MockBean
	TodoItemRepository todoItemRepository;

	TodoItem todoItem;

	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);

	}

	@Test
	void testCreateTodoItem() throws Exception {
		todoItem = new TodoItem();
		todoItem.setId(10);
		todoItem.setItemName("LearningActivity");
		todoItem.setDescription("My favourite activity");
		todoItem.setStatus(false);

		String inputJsonString = this.mapToJson(todoItem);
		String URI = "/api/v1/todoitem";
		Mockito.when(todoItemController.createTodoItem(Mockito.any(TodoItem.class))).thenReturn(todoItem);

		RequestBuilder requestBuilder = MockMvcRequestBuilders.post(URI).accept(MediaType.APPLICATION_JSON)
				.content(inputJsonString).contentType(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		MockHttpServletResponse response = result.getResponse();
		String outputJSONString = response.getContentAsString();
		assertEquals(outputJSONString, inputJsonString); // This test case fails if we manually change the
		// inputJsonString value in this line.
		assertEquals(HttpStatus.OK.value(), response.getStatus());

	}

	private String mapToJson(Object object) throws JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		return objectMapper.writeValueAsString(object);
	}

}
