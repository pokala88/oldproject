package com.fedex.todoitems.todoitemstask.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.fedex.todoitems.todoitemstask.model.TodoItem;

@Repository
public interface TodoItemRepository extends JpaRepository <TodoItem, Integer>{

}

